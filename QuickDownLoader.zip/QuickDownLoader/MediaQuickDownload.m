//
//  MediaQuickDownload.m
//  Forgeter
//
//  Created by Ghanshyam on 6/2/15.
//  Copyright (c) 2015 Ravi Taylor. All rights reserved.
//

#import "MediaQuickDownload.h"
#import <AVFoundation/AVFoundation.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import "UIImage+fixOrientation.h"

@implementation MediaQuickDownload

#pragma mark--
#pragma mark-- NSObject LifeCycle
-(void)dealloc{
    NSLog(@"MediaQuickDownload dealloc");
    
    [self stopDownloading];
}


#pragma mark--
#pragma mark-- Custom Methods
-(void)stopDownloading{
    //Stoping download
    NSLog(@"stopDownloading media quick downloader");
    self.imgMedia = nil;
    self.mediaData = nil;
    if (_mediaQuickRenderer) {
        _mediaQuickRenderer.delegate = nil;
        [_mediaQuickRenderer closeStream];
    }
    self.mediaQuickRenderer =nil;
}


-(void)downloadForgeterMedia:(NSString *)remoteURL{
    self.mediaQuickRenderer    =   [[ImageQuickRender alloc] init];
    self.mediaQuickRenderer.delegate = self;
    
    //http://forgeter.com/uploads/users/1432877727photo.jpg
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *strTmpPath = paths[0];
    NSString *fileName = [[remoteURL componentsSeparatedByString:@"/"] lastObject];
    localMediaURL = [strTmpPath stringByAppendingPathComponent:fileName];
    
    BOOL setUp = [_mediaQuickRenderer setUpCommunication:remoteURL localImageFile:localMediaURL];
    
    if (setUp) {
        NSLog(@"initial setup is done");
    }
}


#pragma mark--
#pragma mark-- Image Rendering Delegate
-(void)communicationReadyToFileDownload{
    //ImageQuickRender is setup for downloading media
    NSLog(@"started file downloading");
    [_mediaQuickRenderer downloadImageFile];
}

-(void)communicationNotReadyToFileDownload{
    //ImageQuickRender is not setup for downloading media
    NSLog(@"communication failed to download media");
    if ([_delegate conformsToProtocol:@protocol(MediaQuickDownloaderDelegate)]
        && [_delegate respondsToSelector:@selector(mediaDownloadFailure)]) {
        [_delegate mediaDownloadFailure];
    }
}

-(void)fileDownloadingDone:(NSData *)data{
    //ImageQuickRender is done with file downloading
    //Stoping download
    
    UIView *contentView = [_imgMedia superview];
    UIActivityIndicatorView *activity = (UIActivityIndicatorView *)[contentView viewWithTag:2];
    if (activity) {
        [activity stopAnimating];
        [activity setHidden:YES];
    }
    
    if(_mediaType == Video){
        NSLog(@"video thumb nail to be recorded local url is %@",localMediaURL);
        NSURL *videoURL = [NSURL fileURLWithPath:localMediaURL];
        [self generateThumbnailIconForVideoFileWith:videoURL WithSize:CGSizeMake(152,40)];
    }
    
    
    [self stopDownloading];
    
    if ([_delegate conformsToProtocol:@protocol(MediaQuickDownloaderDelegate)]
        && [_delegate respondsToSelector:@selector(mediaDownloadedSuccessfully)]) {
        [_delegate mediaDownloadedSuccessfully];
    }
}


-(void)fileDownloadingError{
    //ImageQuickRender failed while downloading
    NSLog(@"file downloading error");
    if ([_delegate conformsToProtocol:@protocol(MediaQuickDownloaderDelegate)]
        && [_delegate respondsToSelector:@selector(mediaDownloadFailure)]) {
        [_delegate mediaDownloadFailure];
    }
}

-(void)didReceiveData:(NSData *)data{

    if (_mediaType == Image) {
        if (!_mediaData) {
            self.mediaData = [[NSMutableData alloc] init];
        }
        [_mediaData appendData:data];
        if (_imgMedia) {
            [self.imgMedia setImage:[UIImage imageWithData:_mediaData]];
        }
    }
}

#pragma mark--
#pragma mark-- Custom Methods
-(void)generateThumbnailIconForVideoFileWith:(NSURL *)contentURL WithSize:(CGSize)size
{
    AVURLAsset *asset = [[AVURLAsset alloc] initWithURL:contentURL options:nil];
    AVAssetImageGenerator *generateImg = [[AVAssetImageGenerator alloc] initWithAsset:asset];
    generateImg.appliesPreferredTrackTransform = TRUE;
    NSError *error = NULL;
    CMTime time = CMTimeMake(1, 65);
    CGImageRef refImg = [generateImg copyCGImageAtTime:time actualTime:NULL error:&error];
    NSLog(@"error==%@, Refimage==%@", error, refImg);
    
    UIImage *FrameImage= [[UIImage alloc] initWithCGImage:refImg];
    [_imgMedia.layer setMasksToBounds:YES];
    FrameImage = FrameImage.fixOrientation;
    _imgMedia.image = FrameImage;
}

@end
